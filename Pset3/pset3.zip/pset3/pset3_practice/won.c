#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// constants


#define DIM_MIN 3
#define DIM_MAX 9

// board





int main(void)
{
    int d = 4;
    
    int tile_count = 0;
    int board_size = d * d;
    int board[4][4] = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{0,14,15,13}};
    int win_check_array[16];
    
    
while (tile_count < board_size)
    {
        for (int i = 0; i < d; i++)
        {
            for (int j = 0; j < d; j++)
            {
                win_check_array[tile_count] = board[i][j];
                tile_count++;
            }
        }
    }
    
    //checks the one-dimensional array to see if it is in correct order.
    for (int i = 0; i < board_size - 2; i++)
    {
        int first_check = win_check_array[i];
        int second_check = win_check_array[i + 1];
        
        if (first_check > second_check)
        {
            return false;
        }
    }
    return true;
} 