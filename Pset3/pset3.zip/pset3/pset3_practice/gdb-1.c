#include <cs50.h>
#include <stdio.h>

int main(void)
{
    printf("Please enter a number: ");
    
    int num = GetInt();
    
    printf("DEBUG before: %i\n", num);
    num = num / 2 + 1;
    printf("DEBUG after: %i\n", num);
    
for (int i = 0; i < num; i++)
    {
        printf("%i!\n", i);
    }
    
    return 0;
}