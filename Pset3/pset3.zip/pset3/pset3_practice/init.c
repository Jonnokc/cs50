#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// constants


#define DIM_MIN 3
#define DIM_MAX 9

// board


int main(void)
{
    d = 4;
    int board[9][9];
  int board_size = (d * d);
    
for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            board_size = board_size - 1;
            board[i][j] = board_size;
            
            if (d % 2 == 0 && board[i][j] == 2)
            {
                board[i][j] = 1;
            }
            
            else if (d % 2 == 0 && board[i][j] == 1)
            {
                board[i][j] = 2;
            }
        }
    }
    
    
        
}