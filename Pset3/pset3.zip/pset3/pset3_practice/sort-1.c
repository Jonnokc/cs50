#include <cs50.h>
#include <stdio.h>



int main(void)
{
    int values[] = {10,9,8,7,6,5,4,3};
    int n = 7;
    
    
    
    for (int i = 0; i < n; i++)
    {
        int min = i;
        
        for (int j = i + 1; j <= n; j++)
        {
            if (values[j] < values[min])
            {
                min = j;
            }
        }
        
        if (min != i)
        {
            int min_hold = values[min];
            int i_hold = values[i];
            
            values[i] = min_hold;
            values[min] = i_hold;
        }
    }
    
    for (int k = 0; k <= n; k++)
    {
        printf("%i ", values[k]);
    }
    
    
}




