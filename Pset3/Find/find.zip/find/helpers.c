/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>

#include "helpers.h"
#include <stdio.h>

/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{
    // TODO: implement a searching algorithm
    int arr_length = n;
    int mid_val = (arr_length / 2);

while (arr_length > 0)
        {
            
            if (value == values[mid_val] || value == values[mid_val+1])
            {
                return true;
                
            }
            
            else if (value < values[mid_val])
            {
                arr_length = arr_length / 2;
                mid_val = mid_val / 2;

            }
            
            else if (value > values[mid_val])
            {
                arr_length = arr_length / 2;
                mid_val = (mid_val + n) / 2;
            }
     
        }
        
        return false;
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    // TODO: implement an O(n^2) sorting algorithm
    for (int i = 0; i < n; i++)
    {
        int min = i;
        
        for (int j = i + 1; j <= n; j++)
        {
            if (values[j] < values[min])
            {
                min = j;
            }
        }
        
        if (min != i)
        {
            int temp = values[min];
            
            values[min] = values[i];
            values[i] = temp;
        }
    }

    return;
}