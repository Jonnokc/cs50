#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// constants


#define DIM_MIN 3
#define DIM_MAX 9

// board





int main(void)
{
    int d = 4;
    int grid[4][4] = {{15,14,13,12},{11,0,9,8},{7,6,5,4},{3,2,1,10}};
    int board = d;
    int tile = 16;
    int grid_whole[d*d];
    int blank_row;
    int blank_col;
    int tile_count = 0;
    int guess_row;
    int guess_col;
    int blank_hold;
    int guess_hold;

    
    //find the location of the blank tile.
    for (int i = 0; i < board; i++)
    {
        for (int j = 0; j < board; j++)
        {
            if (grid[i][j] == 0)
            {
                    blank_row = i;
                    blank_col = j;
                    
                    printf("blank is at %i %i\n", blank_row, blank_col);
            }
        }
    printf("\n");
    }
    
    
    //find the location of the guess to move. User submits the tile in the tile variable
    while (tile_count < tile)
    {
        for (int i = 0; i < board; i++)
        {
            for (int j = 0; j < board; j++)
            {
                if (tile_count + 1 == tile)
                {
                grid_whole[tile_count] = grid[i][j];
                guess_row = i;
                guess_col = j;
                printf("tile count is %i value is %i\n", tile_count, grid_whole[tile_count]);
                printf("Row is %i col is %i\n", guess_row, guess_col);
                tile_count++;
                break;
                }
                else
                {
                  tile_count++;  
                }
            }
        }
    }
    
    
    if (blank_row == guess_row && blank_col == guess_col + 1)
    {
        blank_hold = grid[blank_row][blank_col];
        guess_hold = grid[guess_row][guess_col];
        
        grid[blank_row][blank_col] = guess_hold;
        grid[guess_row][guess_col] = blank_hold;
        
        return true;
        
        
    }
    else if (blank_row == guess_row && blank_col == guess_col - 1)
    {
        blank_hold = grid[blank_row][blank_col];
        guess_hold = grid[guess_row][guess_col];
        
        grid[blank_row][blank_col] = guess_hold;
        grid[guess_row][guess_col] = blank_hold;
        
        return true;
    }
    else if (blank_row == guess_row + 1 && blank_col == guess_col)
    {
        blank_hold = grid[blank_row][blank_col];
        guess_hold = grid[guess_row][guess_col];
        
        grid[blank_row][blank_col] = guess_hold;
        grid[guess_row][guess_col] = blank_hold;
        
        return true;
    }
    else if (blank_row == guess_row - 1 && blank_col == guess_col)
    {
        blank_hold = grid[blank_row][blank_col];
        guess_hold = grid[guess_row][guess_col];
        
        grid[blank_row][blank_col] = guess_hold;
        grid[guess_row][guess_col] = blank_hold;
        
        return true;
    }
    
    else
    {
        printf("DEBUG: Move not legal!\n");
        return false;
    }
    
} 