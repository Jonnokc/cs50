#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// constants


#define DIM_MIN 3
#define DIM_MAX 9

// board


int d = 4;


int main(void)
{
    int board[4][4] = {{15,14,13,12},{11,10,9,8},{7,6,5,4},{3,2,1,0}};
    int d = 4;
    
    for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            if (board[i][j] == 0)
            {
                printf(" _");
            }
            else 
            {
             printf("%2d ", board[i][j]);   
            }
        }
    printf("\n");
    }
}