#include <cs50.h>
#include <stdio.h>
#include <string.h>


int main(int argc, string argv[])
{
    if (argc == 2)
    {
        
   
        if (strcmp("", argv[1]))
        {
            printf("You figured it out!\n");
        }
        else
        {
            printf("Sorry :-(\n");
        }
    }
    else 
    {
        printf("enter text on the command line\n");
    }
}
