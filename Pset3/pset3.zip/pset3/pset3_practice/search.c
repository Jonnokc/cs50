#include <cs50.h>
#include <stdio.h>



int main(void)
{
    int values[] = {1,2,3,4,5,6,7,8};
    int n = 7;
    int arr_length = n;
    int value = 1;


    int mid_val = (arr_length / 2);

while (arr_length > 0)
        {
            
            if (value == values[mid_val] || value == values[mid_val+1])
            {
                printf("I work!\n");
                return true;
                
            }
            
            else if (value < values[mid_val])
            {
                arr_length = arr_length / 2;
                mid_val = mid_val / 2;

            }
            
            else if (value > values[mid_val])
            {
                arr_length = arr_length / 2;
                mid_val = (mid_val + n) / 2;
            }
     
        }
        printf("DEBUG: I dont work\n");
        return false;
}